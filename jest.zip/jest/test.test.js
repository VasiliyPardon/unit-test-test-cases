const test = require('/tesks/unittest.js');

test(
    'Проверяем работоспособность перехода по картинке на форму регистрации пользователя',
    () => {
        expect(goToRegPage()).toBe('src/Auth/auth.php')
    }
)