function goToRegPage() {
    window.location.href = "/src/Auth/auth.php";
}

module.exports = goToRegPage;